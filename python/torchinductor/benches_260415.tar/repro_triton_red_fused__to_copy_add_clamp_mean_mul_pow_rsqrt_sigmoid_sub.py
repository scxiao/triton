#!/usr/bin/env python3
"""
Auto-generated benchmark from AOTI wrapper.cpp

  AMD: triton_red_fused__to_copy_add_clamp_mean_mul_pow_rsqrt_sigmoid_sub_23
    type: reduction, size_hints: {'x': 16, 'r0_': 2048}
    xnumel=None (16), literals=[]
    AUTOTUNE: XBLOCK=2, R0_BLOCK=2048, num_warps=8, time_us=12.36

  NV: triton_red_fused__to_copy_add_clamp_mean_mul_pow_rsqrt_sigmoid_sub_30
    type: reduction, size_hints: {'x': 16, 'r0_': 2048}
    xnumel=None (16), literals=[]
    AUTOTUNE: XBLOCK=1, R0_BLOCK=2048, num_warps=16, time_us=8.64

Usage:
    python3 repro_triton_red_fused_sigmoid_sub_30.py
    python3 repro_triton_red_fused_sigmoid_sub_30.py --platform amd
    python3 repro_triton_red_fused_sigmoid_sub_30.py --platform nv
"""

import argparse
import torch
import triton
import triton.language as tl


try:
    from torch._inductor.runtime import triton_helpers, triton_heuristics
    from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
except ImportError:
    triton_helpers = None
    libdevice = None
    tl_math = None

# ============================================================
# AMD: triton_red_fused__to_copy_add_clamp_mean_mul_pow_rsqrt_sigmoid_sub_23
# xnumel=16, size_hints={'x': 16, 'r0_': 2048}
# AUTOTUNE: XBLOCK=2, R0_BLOCK=2048, num_warps=8, time_us=12.36
# ============================================================
@triton.jit
def triton_red_fused__to_copy_add_clamp_mean_mul_pow_rsqrt_sigmoid_sub_23(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):

        r0_numel = 2048
        rnumel = r0_numel
        RBLOCK: tl.constexpr = R0_BLOCK
        xoffset = tl.program_id(0) * XBLOCK
        xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
        xmask = xindex < xnumel
        r0_base = tl.arange(0, R0_BLOCK)[None, :]
        rbase = r0_base
        x0 = xindex
        _tmp3 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_1 = r0_index
            tmp0 = tl.load(in_out_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp1 = tmp0.to(tl.float32)
            tmp2 = tl.broadcast_to(tmp1, [XBLOCK, R0_BLOCK])
            tmp4 = _tmp3 + tmp2
            _tmp3 = tl.where(r0_mask & xmask, tmp4, _tmp3)
        tmp3 = tl.sum(_tmp3, 1)[:, None]
        _tmp17 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_1 = r0_index
            tmp5 = tl.load(in_out_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp6 = tl.full([1, 1], 2048.0, tl.float32)
            tmp7 = (tmp3 / tmp6)
            tmp8 = tmp7.to(tl.float32)
            tmp9 = tmp5 - tmp8
            tmp10 = tmp9.to(tl.float32)
            tmp11 = tl.full([1, 1], -65504.0, tl.float32)
            tmp12 = tl.maximum(tmp10, tmp11, tl.PropagateNan.ALL)
            tmp13 = tl.full([1, 1], 65504.0, tl.float32)
            tmp14 = tl.minimum(tmp12, tmp13, tl.PropagateNan.ALL)
            tmp15 = tmp14 * tmp14
            tmp16 = tl.broadcast_to(tmp15, [XBLOCK, R0_BLOCK])
            tmp18 = _tmp17 + tmp16
            _tmp17 = tl.where(r0_mask & xmask, tmp18, _tmp17)
        tmp17 = tl.sum(_tmp17, 1)[:, None]
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK, num_stages = 2):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_1 = r0_index
            tmp19 = tl.load(in_out_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
            tmp35 = tl.load(in_ptr0 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp37 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp20 = tl.full([1, 1], 2048.0, tl.float32)
            tmp21 = (tmp3 / tmp20)
            tmp22 = tmp21.to(tl.float32)
            tmp23 = tmp19 - tmp22
            tmp24 = tmp23.to(tl.float32)
            tmp25 = tl.full([1, 1], -65504.0, tl.float32)
            tmp26 = tl.maximum(tmp24, tmp25, tl.PropagateNan.ALL)
            tmp27 = tl.full([1, 1], 65504.0, tl.float32)
            tmp28 = tl.minimum(tmp26, tmp27, tl.PropagateNan.ALL)
            tmp29 = (tmp17 / tmp20)
            tmp30 = tl.full([1, 1], 9.999999747378752e-06, tl.float32)
            tmp31 = tmp29 + tmp30
            tmp32 = tl.rsqrt(tmp31)
            tmp33 = tmp28 * tmp32
            tmp34 = tmp33.to(tl.float32)
            tmp36 = tmp34 * tmp35
            tmp38 = tmp36 + tmp37
            tmp39 = tl.sigmoid(tmp38)
            tmp40 = tmp19 * tmp39
            tl.store(in_out_ptr0 + (r0_1 + 2048*x0), tmp40, r0_mask & xmask)
    

# ============================================================
# NV: triton_red_fused__to_copy_add_clamp_mean_mul_pow_rsqrt_sigmoid_sub_30
# xnumel=16, size_hints={'x': 16, 'r0_': 2048}
# AUTOTUNE: XBLOCK=1, R0_BLOCK=2048, num_warps=16, time_us=8.64
# ============================================================
@triton.jit
def triton_red_fused__to_copy_add_clamp_mean_mul_pow_rsqrt_sigmoid_sub_30(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):

        r0_numel = 2048
        rnumel = r0_numel
        RBLOCK: tl.constexpr = R0_BLOCK
        xoffset = tl.program_id(0).to(tl.int64) * XBLOCK
        xindex = xoffset + tl.arange(0, XBLOCK)[:, None].to(tl.int64)
        xmask = xindex < xnumel
        r0_base = tl.arange(0, R0_BLOCK)[None, :].to(tl.int64)
        rbase = r0_base
        x0 = xindex
        _tmp3 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_1 = r0_index
            tmp0 = tl.load(in_out_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp1 = tmp0.to(tl.float32)
            tmp2 = tl.broadcast_to(tmp1, [XBLOCK, R0_BLOCK])
            tmp4 = _tmp3 + tmp2
            _tmp3 = tl.where(r0_mask & xmask, tmp4, _tmp3)
        tmp3 = tl.sum(_tmp3, 1)[:, None]
        _tmp17 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_1 = r0_index
            tmp5 = tl.load(in_out_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp6 = tl.full([1, 1], 2048.0, tl.float32)
            tmp7 = (tmp3 / tmp6)
            tmp8 = tmp7.to(tl.float32)
            tmp9 = tmp5 - tmp8
            tmp10 = tmp9.to(tl.float32)
            tmp11 = tl.full([1, 1], -65504.0, tl.float32)
            tmp12 = triton_helpers.maximum(tmp10, tmp11)
            tmp13 = tl.full([1, 1], 65504.0, tl.float32)
            tmp14 = triton_helpers.minimum(tmp12, tmp13)
            tmp15 = tmp14 * tmp14
            tmp16 = tl.broadcast_to(tmp15, [XBLOCK, R0_BLOCK])
            tmp18 = _tmp17 + tmp16
            _tmp17 = tl.where(r0_mask & xmask, tmp18, _tmp17)
        tmp17 = tl.sum(_tmp17, 1)[:, None]
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_1 = r0_index
            tmp19 = tl.load(in_out_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
            tmp35 = tl.load(in_ptr0 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp37 = tl.load(in_ptr1 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp20 = tl.full([1, 1], 2048.0, tl.float32)
            tmp21 = (tmp3 / tmp20)
            tmp22 = tmp21.to(tl.float32)
            tmp23 = tmp19 - tmp22
            tmp24 = tmp23.to(tl.float32)
            tmp25 = tl.full([1, 1], -65504.0, tl.float32)
            tmp26 = triton_helpers.maximum(tmp24, tmp25)
            tmp27 = tl.full([1, 1], 65504.0, tl.float32)
            tmp28 = triton_helpers.minimum(tmp26, tmp27)
            tmp29 = (tmp17 / tmp20)
            tmp30 = tl.full([1, 1], 9.999999747378752e-06, tl.float32)
            tmp31 = tmp29 + tmp30
            tmp32 = libdevice.rsqrt(tmp31)
            tmp33 = tmp28 * tmp32
            tmp34 = tmp33.to(tl.float32)
            tmp36 = tmp34 * tmp35
            tmp38 = tmp36 + tmp37
            tmp39 = tl.sigmoid(tmp38)
            tmp40 = tmp19 * tmp39
            tl.store(in_out_ptr0 + (r0_1 + 2048*x0), tmp40, r0_mask & xmask)
    

def benchmark_kernel(kernel_fn, grid_size, kernel_args, constexpr_kwargs, label, iters=100):
    """Benchmark matching Inductor's InductorBenchmarker methodology."""
    # Warmup
    kernel_fn[grid_size](*kernel_args, **constexpr_kwargs)
    torch.cuda.synchronize()

    # L2 flush buffer
    l2_size = torch.cuda.get_device_properties(0).L2_cache_size
    flush_buf = torch.empty(l2_size // 4, dtype=torch.int, device="cuda")

    # Estimation (5 iters)
    est_events = []
    for _ in range(5):
        s = torch.cuda.Event(enable_timing=True)
        e = torch.cuda.Event(enable_timing=True)
        flush_buf.zero_()
        s.record()
        kernel_fn[grid_size](*kernel_args, **constexpr_kwargs)
        e.record()
        est_events.append((s, e))
    torch.cuda.synchronize()
    est_times = [s.elapsed_time(e) for s, e in est_events]
    est_min = min(est_times)

    # Adjust iters
    if est_min > 0:
        iters = max(min(iters, int(25 // est_min)), 1)

    # Memory warmup
    for _ in range(100):
        flush_buf.zero_()

    # Benchmark
    bench_events = []
    for _ in range(iters):
        s = torch.cuda.Event(enable_timing=True)
        e = torch.cuda.Event(enable_timing=True)
        flush_buf.zero_()
        s.record()
        kernel_fn[grid_size](*kernel_args, **constexpr_kwargs)
        e.record()
        bench_events.append((s, e))
    torch.cuda.synchronize()
    bench_times = [s.elapsed_time(e) for s, e in bench_events]

    all_us = sorted([(t * 1000) for t in est_times + bench_times])
    bench_us = sorted([t * 1000 for t in bench_times])
    del flush_buf

    return {
        "min": all_us[0],
        "median": bench_us[len(bench_us) // 2],
        "p10": bench_us[len(bench_us) // 10],
        "p90": bench_us[len(bench_us) * 9 // 10],
        "iters": iters,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--platform", choices=['both', 'amd', 'nv'], default="both")
    parser.add_argument("--iters", type=int, default=100)
    args = parser.parse_args()

    device_name = torch.cuda.get_device_name(0)
    print(f"Device: {device_name}")
    print(f"PyTorch: {torch.__version__}")
    print()

    if args.platform in ("amd", "both"):
        print("--- AMD (triton_red_fused__to_copy_add_clamp_mean_mul_pow_rsqrt_sigmoid_sub_23) ---")
        xnumel = 16
        r0_numel = 2048
        alloc_size = 65536
        in0 = torch.randn(alloc_size, device="cuda", dtype=torch.float16)
        in1 = torch.randn(alloc_size, device="cuda", dtype=torch.float16)
        in2 = torch.randn(alloc_size, device="cuda", dtype=torch.float16)
        constexpr_kwargs = {"XBLOCK": 2, "R0_BLOCK": 2048, "num_warps": 8}
        print(f"  xnumel={xnumel}, r0_numel={r0_numel}, {constexpr_kwargs}")
        grid = (xnumel,)
        r = benchmark_kernel(triton_red_fused__to_copy_add_clamp_mean_mul_pow_rsqrt_sigmoid_sub_23, grid, [in0, in1, in2, xnumel, r0_numel], constexpr_kwargs, "AMD", iters=args.iters)
        print(f"  Min: {r['min']:.1f}us  Median: {r['median']:.1f}us  P10: {r['p10']:.1f}us  P90: {r['p90']:.1f}us  Iters: {r['iters']}")
        print()

    if args.platform in ("nv", "both"):
        print("--- NV (triton_red_fused__to_copy_add_clamp_mean_mul_pow_rsqrt_sigmoid_sub_30) ---")
        xnumel = 16
        r0_numel = 2048
        alloc_size = 65536
        in0 = torch.randn(alloc_size, device="cuda", dtype=torch.float16)
        in1 = torch.randn(alloc_size, device="cuda", dtype=torch.float16)
        in2 = torch.randn(alloc_size, device="cuda", dtype=torch.float16)
        constexpr_kwargs = {"XBLOCK": 1, "R0_BLOCK": 2048, "num_warps": 16}
        print(f"  xnumel={xnumel}, r0_numel={r0_numel}, {constexpr_kwargs}")
        grid = (xnumel,)
        r = benchmark_kernel(triton_red_fused__to_copy_add_clamp_mean_mul_pow_rsqrt_sigmoid_sub_30, grid, [in0, in1, in2, xnumel, r0_numel], constexpr_kwargs, "NV", iters=args.iters)
        print(f"  Min: {r['min']:.1f}us  Median: {r['median']:.1f}us  P10: {r['p10']:.1f}us  P90: {r['p90']:.1f}us  Iters: {r['iters']}")
        print()


if __name__ == "__main__":
    main()
